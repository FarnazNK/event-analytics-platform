# Contributing to Event Analytics Platform

Thank you for your interest in contributing! This document provides guidelines and instructions for contributing to this project.

## 🔐 Security First

**Before contributing, please review [SECURITY.md](SECURITY.md)** to understand our security requirements and practices.

### Security Guidelines for Contributors

1. **Never commit secrets**: No API keys, passwords, or tokens
2. **Validate all inputs**: Use Pydantic schemas
3. **Prevent SQL injection**: Always use ORM or parameterized queries
4. **Sanitize outputs**: Escape HTML, prevent XSS
5. **Follow security best practices**: See SECURITY.md

## 🚀 Getting Started

### Prerequisites

- Python 3.11+
- PostgreSQL 14+ or MySQL 8+
- Redis 7+
- Docker & Docker Compose (for containerized development)
- Git

### Development Setup

1. **Fork and clone the repository**
   ```bash
   git clone https://github.com/yourusername/event-analytics-platform.git
   cd event-analytics-platform
   ```

2. **Create a virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   pip install -r requirements-dev.txt  # Development dependencies
   ```

4. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your local configuration
   # Generate SECRET_KEY: openssl rand -hex 32
   ```

5. **Initialize database**
   ```bash
   python scripts/init_db.py
   ```

6. **Run tests**
   ```bash
   pytest
   ```

7. **Start the application**
   ```bash
   uvicorn app.main:app --reload
   ```

## 📝 Development Workflow

### Branch Strategy

- `main` - Production-ready code
- `develop` - Development branch
- `feature/feature-name` - New features
- `bugfix/bug-name` - Bug fixes
- `security/security-fix` - Security patches

### Commit Messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
feat: add user authentication
fix: resolve SQL injection vulnerability
docs: update API documentation
test: add security tests for auth
refactor: improve cache performance
security: patch XSS vulnerability
```

### Pull Request Process

1. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes**
   - Write clear, documented code
   - Add tests for new features
   - Update documentation

3. **Run quality checks**
   ```bash
   # Format code
   black app/ tests/
   isort app/ tests/
   
   # Lint code
   flake8 app/ tests/
   pylint app/
   
   # Type check
   mypy app/
   
   # Security scan
   bandit -r app/
   safety check
   
   # Run tests
   pytest --cov=app
   ```

4. **Commit and push**
   ```bash
   git add .
   git commit -m "feat: add your feature"
   git push origin feature/your-feature-name
   ```

5. **Create Pull Request**
   - Use the PR template
   - Link related issues
   - Request reviews
   - Address feedback

## 🧪 Testing

### Test Requirements

All contributions must include appropriate tests:

- **Unit tests**: Test individual functions/methods
- **Integration tests**: Test component interactions
- **Security tests**: Test security features
- **Performance tests**: For performance-critical code

### Running Tests

```bash
# All tests
pytest

# Specific test file
pytest tests/test_security.py

# Specific test class
pytest tests/test_security.py::TestPasswordSecurity

# With coverage
pytest --cov=app --cov-report=html

# Security tests only
pytest tests/security/

# Performance tests
pytest tests/performance/
```

### Writing Tests

```python
import pytest
from fastapi.testclient import TestClient

class TestYourFeature:
    """Test your feature."""
    
    def test_feature_works(self):
        """Test that feature works correctly."""
        # Arrange
        client = TestClient(app)
        
        # Act
        response = client.get("/your-endpoint")
        
        # Assert
        assert response.status_code == 200
    
    def test_feature_handles_errors(self):
        """Test error handling."""
        # Test error cases
        pass
    
    def test_feature_security(self):
        """Test security aspects."""
        # Test input validation, auth, etc.
        pass
```

## 📖 Documentation

### Code Documentation

- Use docstrings for all functions, classes, and modules
- Follow [Google Python Style Guide](https://google.github.io/styleguide/pyguide.html)
- Include examples in docstrings
- Document security considerations

Example:
```python
def create_user(email: str, password: str) -> User:
    """
    Create a new user with secure password hashing.
    
    Args:
        email: User's email address (validated)
        password: Plain text password (will be hashed)
        
    Returns:
        User: Created user object
        
    Raises:
        ValueError: If email is invalid or password is weak
        
    Security Notes:
        - Password is hashed with bcrypt
        - Email is validated before storage
        - SQL injection prevented via ORM
        
    Example:
        >>> user = create_user("user@example.com", "StrongP@ss123")
        >>> user.email
        'user@example.com'
    """
    # Implementation
```

### API Documentation

- Update OpenAPI/Swagger docs for API changes
- Include request/response examples
- Document error responses
- Specify authentication requirements

## 🎨 Code Style

### Python Style

- Follow [PEP 8](https://pep8.org/)
- Use [Black](https://black.readthedocs.io/) for formatting
- Maximum line length: 88 characters (Black default)
- Use type hints where possible

### Import Order

```python
# Standard library imports
import os
import sys

# Third-party imports
from fastapi import FastAPI
import sqlalchemy

# Local application imports
from app.core.config import settings
from app.models import User
```

### Naming Conventions

- Classes: `PascalCase`
- Functions/methods: `snake_case`
- Constants: `UPPER_SNAKE_CASE`
- Private members: `_leading_underscore`

## 🔍 Code Review

### What We Look For

1. **Security**
   - No SQL injection vulnerabilities
   - No XSS vulnerabilities
   - Proper input validation
   - No hardcoded secrets

2. **Code Quality**
   - Clear, readable code
   - Proper error handling
   - Good test coverage
   - Documentation

3. **Performance**
   - Efficient algorithms
   - Proper caching
   - Database query optimization
   - No memory leaks

4. **Maintainability**
   - DRY (Don't Repeat Yourself)
   - SOLID principles
   - Clear naming
   - Modular design

### Review Checklist

- [ ] Code follows style guide
- [ ] Tests pass and have good coverage
- [ ] Documentation updated
- [ ] Security scan passes
- [ ] No merge conflicts
- [ ] Commit messages are clear
- [ ] PR description is complete

## 🐛 Reporting Bugs

### Bug Reports Should Include

1. **Description**: Clear description of the bug
2. **Steps to reproduce**: Detailed steps
3. **Expected behavior**: What should happen
4. **Actual behavior**: What actually happens
5. **Environment**: OS, Python version, etc.
6. **Logs**: Relevant error messages/logs

### Security Vulnerabilities

**DO NOT** create public issues for security vulnerabilities.

Instead:
- Email: security@example.com
- Or use GitHub Security Advisories

See [SECURITY.md](SECURITY.md) for details.

## 💡 Suggesting Features

### Feature Requests Should Include

1. **Use case**: Why is this needed?
2. **Proposed solution**: How should it work?
3. **Alternatives**: Other approaches considered
4. **Additional context**: Screenshots, examples, etc.

## 📜 License

By contributing, you agree that your contributions will be licensed under the MIT License.

## 🙋 Questions?

- **General questions**: Open a GitHub Discussion
- **Bug reports**: Create a GitHub Issue
- **Security issues**: Email security@example.com
- **Feature requests**: Create a GitHub Issue

## 🎉 Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes
- Project documentation

Thank you for contributing to Event Analytics Platform!
